﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aarons_wood_milestone1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void placeOrderBttn_Click(object sender, EventArgs e)
        {

        }

        private void orderBttn_Click(object sender, EventArgs e)
        {

        }

        private void inventoryBttn_Click(object sender, EventArgs e)
        {

        }

        private void usersBttn_Click(object sender, EventArgs e)
        {

        }

        private void menuBttn_Click(object sender, EventArgs e)
        {

        }

        private void reportsBttn_Click(object sender, EventArgs e)
        {

        }
    }
}
